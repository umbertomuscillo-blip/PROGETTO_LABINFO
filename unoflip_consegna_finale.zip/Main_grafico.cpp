#include <SFML/Graphics.hpp>
#include <iostream>
#include "SceneManager.h"
#include "LoginScene.h"

int main() {
    sf::ContextSettings settings;
    sf::RenderWindow window(sf::VideoMode({1024, 768}), "UNO Flip! - Premium Edition", sf::Style::Default, sf::State::Windowed, settings);
    window.setFramerateLimit(60);

    SceneManager manager;
    if (!manager.initialize()) {
        std::cerr << "Errore inizializzazione SceneManager (font mancante?)" << std::endl;
        return -1;
    }

    // Imposta la scena iniziale
    manager.changeScene(std::make_unique<LoginScene>(&manager));

    sf::Clock clock;

    while (window.isOpen()) {
        float deltaTime = clock.restart().asSeconds();

        while (const std::optional<sf::Event> event = window.pollEvent()) {
            if (event->is<sf::Event::Closed>()) {
                window.close();
            }
            manager.handleInput(event, window);
        }

        manager.update(deltaTime, window);

        window.clear(sf::Color::Black);
        manager.render(window);
        window.display();
    }

    return 0;
}